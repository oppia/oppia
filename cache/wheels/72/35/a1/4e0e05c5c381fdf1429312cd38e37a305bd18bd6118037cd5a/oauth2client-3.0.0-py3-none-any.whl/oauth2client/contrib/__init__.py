"""Contributed modules.

Contrib contains modules that are not considered part of the core oauth2client
library but provide additional functionality. These modules are intended to
make it easier to use oauth2client.
"""
