#include <stdio.h>

int main(void)
{
  printf("Goodbye World\n");
  return 0;
}
